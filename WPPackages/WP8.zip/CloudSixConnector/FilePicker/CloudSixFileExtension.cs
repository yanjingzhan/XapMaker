﻿namespace CloudSixConnector.FilePicker
{
    using System;
    using System.Runtime.CompilerServices;

    public class CloudSixFileExtension
    {
        public string Extension { get; set; }

        public int MaxFileSizeInKb { get; set; }
    }
}

