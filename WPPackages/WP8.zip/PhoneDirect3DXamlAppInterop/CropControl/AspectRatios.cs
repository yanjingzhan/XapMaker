﻿namespace CropControl
{
    using System;

    public enum AspectRatios
    {
        None,
        R43
    }
}

