﻿namespace PhoneDirect3DXamlAppInterop
{
    using System;
    using System.Runtime.CompilerServices;

    public class ToolTipData
    {
        public string Description { get; set; }
    }
}

