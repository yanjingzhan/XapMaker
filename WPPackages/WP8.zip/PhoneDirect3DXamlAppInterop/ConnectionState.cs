﻿namespace PhoneDirect3DXamlAppInterop
{
    using System;

    internal enum ConnectionState
    {
        LINK_OK,
        LINK_ERROR,
        LINK_NEEDS_UPDATE,
        LINK_ABORT
    }
}

