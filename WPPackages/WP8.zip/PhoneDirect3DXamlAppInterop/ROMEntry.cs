﻿namespace PhoneDirect3DXamlAppInterop
{
    using System;
    using System.Runtime.CompilerServices;

    internal class ROMEntry
    {
        public string Name { get; set; }
    }
}

