﻿namespace PhoneDirect3DXamlAppInterop
{
    using System;
    using System.Runtime.CompilerServices;

    public class CheatInfo
    {
        public string ARLink { get; set; }

        public string GSLink { get; set; }

        public bool HasAR { get; set; }

        public bool HasGS { get; set; }

        public string Title { get; set; }
    }
}

