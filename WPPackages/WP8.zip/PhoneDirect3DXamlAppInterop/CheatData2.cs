﻿namespace PhoneDirect3DXamlAppInterop
{
    using System;
    using System.Runtime.CompilerServices;

    internal class CheatData2
    {
        public string CheatCode { get; set; }

        public string Description { get; set; }

        public bool Enabled { get; set; }
    }
}

