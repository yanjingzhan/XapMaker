﻿namespace PhoneDirect3DXamlAppInterop
{
    using System.Windows.Controls;

    public class TiltableGrid : Grid
    {
    }
}

