﻿namespace PhoneDirect3DXamlAppInterop.Database
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void CommitDelegate();
}

