﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhoneDirect3DXamlAppInterop.Framework
{
    public class ContentManage
    {
        public static string ContenRoot;
        public static string AudiosContent;
        public static string LevelContent;
        public static string GameUI;
        public static string Levels;
        public static string StartImages;
    }
}
