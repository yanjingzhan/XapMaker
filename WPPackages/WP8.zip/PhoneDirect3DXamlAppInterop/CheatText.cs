﻿namespace PhoneDirect3DXamlAppInterop
{
    using System;
    using System.Runtime.CompilerServices;

    public class CheatText
    {
        public string Text { get; set; }

        public string TextHtml { get; set; }

        public string Title { get; set; }

        public string Url { get; set; }
    }
}

