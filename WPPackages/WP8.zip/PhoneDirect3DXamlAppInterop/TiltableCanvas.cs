﻿namespace PhoneDirect3DXamlAppInterop
{
    using System.Windows.Controls;

    public class TiltableCanvas : Canvas
    {
    }
}

